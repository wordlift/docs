# WordLift SEO Audit Skill — Setup Guide

**Version**: 1.1.0
**Last Updated**: June 2026

## What this skill does

The WordLift SEO Audit Skill asks **Agent WordLift** (via the WordLift MCP server) to run a **comprehensive SEO and AI-readiness audit of a single URL** and returns a WordLift-branded report.

The underlying capability is the [Website Audit API](https://docs.wordlift.io/api/audit/audit-website/). The Skill never calls that HTTP endpoint directly — it delegates to Agent WordLift, which owns the audit capability.

> **Note**: This version is single-URL only. Competitor / SERP analysis is planned for a follow-up release.

## Architecture

```
┌─────────────────────────────────────┐
│   Claude (with Agent Skills)        │
│   ├── SKILL.md (v1.1.0)             │   methodology + invocation
│   ├── REPORT_FORMAT.md              │   report layout
│   └── resources/BRANDING.md         │   brand palette + typography
└─────────────────┬───────────────────┘
                  │  WordLift:agent (MCP)
                  ▼
┌─────────────────────────────────────┐
│   WordLift MCP Server               │
│   https://mcp.wordlift.io/sse       │
│   exposes Agent WordLift            │
└─────────────────┬───────────────────┘
                  │  internal capability
                  ▼
┌─────────────────────────────────────┐
│   Agent WordLift — website audit    │
│   (wraps POST /audit internally)    │
└─────────────────────────────────────┘
```

## Project structure

```
wl-seo-audit/
├── SKILL.md                    # Main skill file (loaded on trigger)
├── REPORT_FORMAT.md            # Audit report layout
├── SETUP.md                    # This file
├── CHANGELOG.md                # Version history
└── resources/
    └── BRANDING.md             # WordLift brand guidelines
```

## Install

### Step 1 — Configure the WordLift MCP Server

**Claude Desktop / Web**

1. Open Claude Settings → **Integrations**.
2. Click **Add more**.
3. Enter:
   - **Integration name**: `WordLift`
   - **Integration URL**: `https://mcp.wordlift.io/sse`
4. Save and enable the tools in new chats.

**Cursor / Windsurf / VS Code**

```json
{
  "mcpServers": {
    "wordlift": {
      "command": "npx",
      "args": ["-y", "mcp-remote", "https://mcp.wordlift.io/sse"]
    }
  }
}
```

For header-based authentication and more options, see <https://docs.wordlift.io/agent-wordlift/integrations/>.

### Step 2 — Upload the skill bundle

1. Zip the `wl-seo-audit/` folder.
2. In Claude, go to **Settings → Capabilities → Upload Skill**.
3. Select the zip file.
4. Enable the `wordlift-seo-audit` skill in conversations where you want to use it.

### Step 3 — Run an audit

```
Audit https://example.com and tell me the overall score and the top quick wins.
```

```
Run a WordLift SEO audit on https://example.com/products/backpack — focus on llms.txt, MCP discovery, and bot access.
```

## What the report includes

- **Overall SEO and AI-readiness score** (0-100)
- **Quick Stats Dashboard** — schema types, critical issues, quick wins, allowed AI bots
- **Score Breakdown** — site files, SEO fundamentals, structured data, content structure, image accessibility, automation readiness, JS rendering
- **Quick Wins** — ranked by impact
- **Site Files & Discovery Surfaces** — robots.txt, llms.txt, `SKILL.md`, `.well-known/` MCP / WebMCP / Agent Skills surfaces, AI bot allow/block matrix
- **Structured Data Inventory** — detected schemas and missing recommendations
- **SEO Fundamentals** — title, meta description, H1 count
- **Content & Accessibility** — token budget, semantic HTML, image alt coverage
- **Automation Readiness** — prioritized WCAG / agent compatibility issues
- **JavaScript Rendering** — framework, rendering type, recommendations

## Troubleshooting

### `WordLift:agent` is not available

The WordLift MCP integration is missing or disabled. Re-run Step 1 and confirm `https://mcp.wordlift.io/sse` is enabled in the host. There is no standalone `WordLift:audit` tool — the audit is always reached through `WordLift:agent`.

### Agent returns `401` / authentication error

Re-authenticate the WordLift integration in the host.

### Agent returns `403` / bot protection detected

The target site blocks the auditor. Try a different URL on the same domain or contact WordLift support.

### Overall score looks low for an otherwise healthy site

Check site files and `.well-known` surfaces — missing MCP / WebMCP / Agent Skills discovery and missing `SKILL.md` can cost up to **+6** in post-hoc bonuses. A token budget above 30 000 forfeits another **+2**.

### Skill does not trigger

Use trigger phrases like "audit", "SEO audit", "AI-readiness", "llms.txt", "MCP discovery", "bot access".

## References

- **Audit API reference** — <https://docs.wordlift.io/api/audit/audit-website/>
- **WordLift MCP integration** — <https://docs.wordlift.io/agent-wordlift/integrations/#agent-wordlift-model-context-protocol-mcp-integration>
- **WordLift docs home** — <https://docs.wordlift.io/>
