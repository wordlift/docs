# WordLift SEO Audit — Report Format

**Version**: 1.1.0
**Last Updated**: June 2026

This document defines the structure for presenting results from the WordLift **Audit API** (`POST https://api.wordlift.io/audit`).

All reports MUST follow WordLift brand guidelines. See [resources/BRANDING.md](resources/BRANDING.md) for colors, typography, and usage rules.

---

## Source of truth

The full response schema is documented at <https://docs.wordlift.io/api/audit/audit-website/>.

The response root is:

```json
{
  "success": true,
  "data": { ... }
}
```

All fields below refer to keys under `data`.

---

## Report layout

### 1. Header

Required elements:

- Title — `🎯 SEO Audit Report: <domain>`
- Target URL — `data.url`
- Audit timestamp — `data.timestamp` (ISO 8601)
- Overall score — `data.overallScore` (also exposed as `data.score`)
- Verdict line based on the score band
- Attribution — `*Powered by WordLift Enterprise SEO Platform*`

Score bands:

| Range | Color | Verdict |
|-------|-------|---------|
| 80-100 | Leaf `#22A286` | ✅ Excellent |
| 60-79 | Sand `#C2A41D` | 👍 Good — Room for Improvement |
| 0-59 | Berry `#D55471` | 🔴 Needs Work |

### 2. Quick Stats Dashboard

A compact table summarising the audit:

| 📦 Schema types | 🔴 Critical issues | 💡 Quick wins | ✅ Allowed AI bots |
|----------------|--------------------|---------------|--------------------|
| `data.structuredData.detectedSchemas.length` | count of `automationReadiness.issues[]` with `priority` ≤ P1 plus any criterion with `status: "Poor"` | `data.quickWins.wins.length` | count of `data.siteFiles.botStatus[]` with `status: "Allowed"` |

Follow with a 2-3 sentence assessment derived from `data.summary`.

### 3. Score Breakdown

Render one progress bar per criterion. Each criterion exposes a numeric `score` plus `status` and `explanation`.

| Criterion | Field | Max | Suggested icon |
|-----------|-------|-----|----------------|
| Site files | `data.siteFiles.score` | 10 | 📁 |
| SEO fundamentals | `data.seoFundamentals.score` | 20 | 🔎 |
| Structured data | `data.structuredData.score` | varies | 🏷️ |
| Content structure | `data.contentStructure.score` | varies | ✍️ |
| Image accessibility | `data.imageAccessibility.score` | varies | 🖼️ |
| Automation readiness | `data.automationReadiness.score` | varies | 🤖 |
| JS rendering | `data.jsRendering.score` | varies | ⚡ |

For each bar:

- Use the color matching the `status` value:
  - `Good` → Leaf
  - `Needs Improvement` → Sand
  - `Poor` → Berry
  - `Unknown` → grey (skip or label "Not analyzed")
- Display the `explanation` underneath, trimmed to 2-3 sentences.

> **Skip legacy fields** with `status: "Unknown"`: `htmlSemantics`, `contentFreshness`, `internalLinking`. Do not present them as failures.

### 4. Quick Wins

Pull from `data.quickWins.wins[]`. Each entry has `title`, `description`, and `impact` (`High` / `Medium` / `Low`).

Order by impact (High → Medium → Low) and format as:

```markdown
### ⚡ <title>
**Impact**: 🔴 High | **Source**: WordLift Audit

<description>
```

Use Berry for High, Sand for Medium, Sky for Low impact badges.

### 5. Site Files & Discovery Surfaces

Source: `data.siteFiles`.

**File presence checklist**

| File | Field | Notes |
|------|-------|-------|
| `robots.txt` | `robotsTxt` | `found` / `not_found` / `error` |
| `llms.txt` | `llmsTxt` + `hasLlmsTxt` | Both flags should agree |
| Top-level `SKILL.md` | `hasSkillMd` | Contributes +2 to overall score |

**Well-known discovery surfaces** — `data.siteFiles.wellKnown`:

| Surface | Field | Bonus |
|---------|-------|-------|
| `<link rel="mcp">` HTML tag | `mcpLinkTag` (+ `mcpEndpoint`) | +1 |
| `/.well-known/webmcp/tools.json` | `webmcpToolsJson` | +1 |
| `/.well-known/mcp.json` | `mcpJson` | +1 (shared with `mcpServerCard`) |
| `/.well-known/mcp/server-card.json` | `mcpServerCard` | +1 (shared with `mcpJson`) |
| `/.well-known/agent-skills/index.json` | `agentSkillsIndex` (+ `agentSkillsCount`) | +2 |

**Bot allow/block matrix** — `data.siteFiles.botStatus[]`. Render as a table with columns `Bot`, `Vendor`, `Status`. Use Leaf for `Allowed`, Berry for `Blocked`.

### 6. Structured Data Inventory

Source: `data.structuredData`.

- Display `hasSchema`, `hasJsonLd`, `hasMicrodata` as three boolean badges.
- Render `detectedSchemas[]` as a "Found" list. Each entry is an object `{ type, format }` (for example `{ "type": "Organization", "format": "JSON-LD" }`); show `type` as the primary label and `format` as a secondary badge.
- Render `recommendations[]` as a "Missing / recommended" list, each entry with `title` and `description`.

### 7. SEO Fundamentals

Source: `data.seoFundamentals`.

Show:

- Title — `title`
- Meta description — `description`
- H1 count — `h1Count` (call out `0` as Critical, `>1` as Warning)
- `explanation`

### 8. Content & Accessibility

- Content structure — `data.contentStructure`:
  - `hasSemanticElements`, `hasLandmarks` as badges
  - `tokenCount` and `tokenBudgetStatus` (Good / Needs Improvement / Poor). Call out that ≤ 30 000 tokens earns a +2 overall bonus.
- Image accessibility — `data.imageAccessibility`:
  - `totalImages`, `imagesWithoutAlt`
  - First 5 entries of `missingAltTextImages` as a bullet list (if present)

### 9. Automation Readiness

Source: `data.automationReadiness.issues[]`. Each issue has `priority`, `criterion`, `what`, `where`, `why`, `how`, `compliance`.

For each issue:

```markdown
### 🔴 [<priority>] <criterion>
**Compliance**: <compliance>

- **What**: <what>
- **Where**: <where>
- **Why**: <why>
- **How**: <how>
```

Sort by `priority` (`P1` highest). Color-code by priority:

- `P1` → Berry
- `P2` → Sand
- `P3` and below → Sky

### 10. JavaScript Rendering

Source: `data.jsRendering`.

Show:

- Framework — `frameworkDetected`
- Rendering type — `renderingType` (`CSR`, `SSR`, `SSG`, `Hybrid`)
- Content availability — `contentAvailability`
- Status + `explanation`
- `recommendations[]` as a numbered list

### 11. Footer

```markdown
---

**WordLift** | Enterprise SEO Solutions
Structured Data • Knowledge Graphs • AI-Powered Insights

*Report generated on <date> using the WordLift Audit API.*
```

---

## Example response → report mapping

Given this excerpt from the API:

```json
{
  "success": true,
  "data": {
    "url": "https://www.wordlift.io/",
    "overallScore": 55,
    "summary": "Wordlift.io presents itself as an AI-powered SEO platform...",
    "siteFiles": {
      "score": 7,
      "status": "Needs Improvement",
      "hasLlmsTxt": true,
      "hasSkillMd": false,
      "botStatus": [
        { "name": "GPTBot", "vendor": "OpenAI", "status": "Allowed" },
        { "name": "Claude-Web", "vendor": "Anthropic", "status": "Allowed" }
      ],
      "wellKnown": {
        "mcpJson": false,
        "mcpServerCard": false,
        "webmcpToolsJson": false,
        "mcpLinkTag": false,
        "agentSkillsIndex": false,
        "agentSkillsCount": 0
      }
    },
    "quickWins": {
      "wins": [
        { "title": "Implement JSON-LD Schema Markup", "description": "Add relevant schema markup...", "impact": "High" },
        { "title": "Add Alt Text to All Images", "description": "Ensure all images have descriptive alt text...", "impact": "Medium" }
      ]
    }
  }
}
```

The header would render as:

```markdown
# 🎯 SEO Audit Report: wordlift.io

**Target**: https://www.wordlift.io/
**Audited**: 2026-01-27
**Overall Score**: **55 / 100** 🔴 Needs Work

*Powered by WordLift Enterprise SEO Platform*
```

And the Site Files block would call out that `SKILL.md` and **all** `.well-known` discovery surfaces are missing — the easiest path to recover **up to +5** on the overall score.

---

## Presentation rules

- Use Markdown tables and progress bars; do not paste raw JSON.
- Wrap schema names, property names, and file paths in backticks.
- Use the WordLift brand palette consistently (see `resources/BRANDING.md`).
- Always include the "Powered by WordLift" attribution line in the header and the WordLift footer block.
- Never invent fields. If a value is missing, label the section "Not reported".

## Anti-patterns

- ❌ Reporting `htmlSemantics`, `contentFreshness`, or `internalLinking` as a failed criterion — they are legacy `Unknown` fields.
- ❌ Mixing per-criterion scores (different max ranges) with the 0-100 `overallScore` on the same scale.
- ❌ Adding fabricated competitor data — this version is single-URL only.
- ❌ Showing the raw API response instead of a formatted report.
