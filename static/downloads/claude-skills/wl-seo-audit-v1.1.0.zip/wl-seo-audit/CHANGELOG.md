# Changelog

All notable changes to the WordLift SEO Audit Skill will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.0] - 2026-06-22

### Changed

- **Aligned the Skill with the current WordLift Audit capability** (documented at <https://docs.wordlift.io/api/audit/audit-website/>).
- Renamed the skill folder from `wl-seo-audit-competitors` to `wl-seo-audit` to reflect the single-URL scope of this release.
- Clarified the **invocation path**: the Skill calls `WordLift:agent` over MCP and asks Agent WordLift to run the audit. There is no standalone `WordLift:audit` MCP tool, and the Skill does not call `POST https://api.wordlift.io/audit` directly. The HTTP endpoint is documented for users who want to integrate it from their own code, but it is out of scope for the Skill.
- Rewrote `SKILL.md` around the live audit capability:
  - Single required input: `url`.
  - Documented the full success response shape (site files, SEO fundamentals, structured data, content structure, image accessibility, automation readiness, JS rendering, quick wins).
  - Documented the post-hoc bonuses that shape `overallScore` (`<link rel="mcp">`, WebMCP `tools.json`, legacy MCP manifests, Agent Skills Discovery / `SKILL.md`, ≤ 30 000-token budget).
  - Added explicit handling for the error states the agent can surface (`400`, `401`, `403`, `404`, `422`, `500`).
  - Flagged `htmlSemantics`, `contentFreshness`, and `internalLinking` as legacy `Unknown` fields that must not be scored as failures.
- Rewrote `REPORT_FORMAT.md` to map every report section to a real field in the audit response, including the bot allow/block matrix and the `.well-known` discovery surfaces.
- Rewrote `SETUP.md` for the single-URL workflow and the current MCP install steps.

### Validated

- Live response shape against `https://wordlift.io/` (2026-06-22): every field referenced in `SKILL.md` and `REPORT_FORMAT.md` is present, no extra fields, no missing fields. Array-item shapes verified for `siteFiles.botStatus` (`{name, vendor, status}`), `structuredData.detectedSchemas` (`{type, format}`), `structuredData.recommendations` (`{title, description}`), `automationReadiness.issues` (`{priority, criterion, what, where, why, how, compliance}`), and `quickWins.wins` (`{title, description, impact}`).

### Removed

- **Competitor / SERP analysis** is no longer part of this Skill. The previous `seo_audit_competitors` task and all references to SERP fan-out, schema diff, and competitor schema scoring have been removed. A separate, dedicated Skill backed by the AI Visibility / Query Fan-Out API will cover that workflow in a future release.

### Migration notes

If you used v1.0.0:

- The MCP setup is unchanged — keep `https://mcp.wordlift.io/sse`.
- The skill ID is `wordlift-seo-audit` (unchanged in `name`); the folder name changed from `wl-seo-audit-competitors` to `wl-seo-audit`.
- Prompts that explicitly asked for "top 5 competitors" or "SERP comparison" will now produce a single-URL audit. Drop the competitor wording, or wait for the upcoming competitor Skill.
- Reports no longer contain the "Competitive Analysis" section. All other sections (score breakdown, quick wins, structured data inventory) map to the live Audit API response.

## [1.0.0] - 2025-10-21

Initial release as `wl-seo-audit-competitors` — combined single-URL audit and competitor / SERP analysis via the `seo_audit_competitors` MCP task.
