# Changelog — agent-wordlift

## 1.1.0 — 2026-07-14

- Merged the standalone **WordLift SEO Audit Skill** (wl-seo-audit-competitors
  v1.0.0) into this skill:
  - `references/seo-audit.md` — audit methodology, `seo_audit_competitors`
    invocation, result processing, seven-section report structure
  - `references/seo-audit-report-format.md` — detailed report examples and
    React component reference (carried over intact)
  - `references/branding.md` — WordLift brand guidelines (carried over intact)
- SKILL.md: audit routing rule added; description extended with audit
  triggers.
- The standalone SEO Audit skill is deprecated; uninstall it to avoid
  double-triggering.

## 1.0.0 — 2026-07-14

- Initial release: MCP tool routing, live-verified GraphQL reference,
  prompt library, 11 workflow recipes.
