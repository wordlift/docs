# Agent WordLift Prompt Library (for `wordlift_agent`)

Send these as the `message` argument. Replace bracketed placeholders. Keep
one task per call; include full URLs, quoted keywords, and market/locale.
Source: docs.wordlift.io/agent-wordlift/prompt-reference (condensed).

## Analysis & Research

- `analyze this text to identify the main entities and keywords: [text]`
- `analyze the entities on this webpage: [URL]`
- `analyze the query '[query]' on [google.com|google.de|…]`
- `perform a domain-specific search for articles related to '[topic]' on my website`
- `analyze the trends for '[keyword1]' and '[keyword2]'`
- `Provide me with insights on the Reddit exposure of the following domains: [domain]`

## Google AI Search (AI Overview, AI Mode, Shopping)

- `Get me the organic AI overview for "[keyword]"`
- `Get the AI mode result for: [query]`
- `What are the top products for "[keyword]" according to Google AI Mode?`
- `Check if Google is showing an AI Overview for the query "[keyword]" in [Country]`
- `Analyze the Google AI Overview for "[keyword]" and tell me which websites are being cited`
- Batch detection: list keywords one per line, ask which trigger an AI Overview
- `Compare the Google AI Overview (standard search) with the Google AI Mode response for the query "[keyword]". Highlight differences in cited sources, answer depth, and follow-up topics.`

## SEO & Technical Analysis

- `perform an entity gap analysis for '[URL]' against the query '[query]'`
- `evaluate the content quality for the keyword '[keyword]' in relation to the content on '[URL]'`
- `analyze the markup of the page at [URL], focusing on the JSON-LD. Provide a brief review and recommendations.`
- Schema comparison: analyze JSON-LD of [URL] → SERP analysis for "[query]" → extract top-3 result schema types → comparison table → recommendations
- `generate keyword suggestions based on '[keyword]'`
- `fact-check this statement: '[statement]'`
- `generate a mind map to visualize the topic clusters for '[topic]'`

## Google Search Console (requires GSC connected to the WordLift account)

- `show me the top 10 queries that have high impressions but low CTR over the last 30 days`
- `compare desktop vs. mobile performance for my top 20 landing pages in the last 14 days`
- `identify new keyword opportunities where I'm ranking on page 2 (positions 11-20)`
- `analyze my Google Search Console data for the search type "discover": top 20 pages by clicks over the last 30 days with clicks, impressions, CTR`

## Google Analytics 4 (requires GA4 connected)

- `provide an analysis of all AI referral traffic over the last week`
- `show the top landing pages by sessions, engagement rate, and conversions over the last 30 days`
- `compare organic search traffic vs AI referral traffic for the last 28 days, including sessions, engaged sessions, and conversion rate`

## Content Creation & Enhancement

- `expand the content of this URL '[URL]' by focusing on the entities '[entity1]' and '[entity2]'`
- `create a new article about '[topic]' using insights from our website's existing content`
- Meta tags: `search the site and generate an SEO-optimized meta title (<60 chars) and meta description (<160 chars) for [URL], using the Keyword Suggestion tool for high-impact keywords`
- AI snapshot: `run a search on '[topic]' using only the content on this website; produce a three-sentence AI-powered snapshot with anchor-text links to supporting articles`

## Internal Linking

- `find content on my website from the '[title]' page ([URL]). Identify up to 5 related articles; for each, pick a keyword, generate keyword suggestions, and create an anchor text ≤30 characters. Compile the HTML for all 5 links.`
- Batch: repeat for a list of Title/URL pairs; never link to the homepage; anchors by content relevance and keyword opportunity.

## Product Content

- `find everything on the website about [product]; write 4-6 product highlights, 1-150 characters each, quick-to-scan, no discounts`

## Social Media

- `search for content related to '[topic1]', '[topic2]' and create content buckets for social media`
- `search for '[topic]', analyze the writing style on my website, and create an X thread for [audience] with links back to the site`

## HTML / CRO

- `extract html from '[URL]' and analyze: visual hierarchy, CTA placement, messaging clarity, UX, trust signals; recommend conversion improvements`

## Local SEO

- `Analyze the Google Business Profile for "[business]" in "[City,State,Country]"`
- `Show me the Local Pack results for "[keyword]" in "[City,State,Country]"`
- `Track the rankings of "[business]" for "[keyword]" in "[City,State,Country]"`
- `Analyze questions and answers for "[business]" in "[City,State,Country]"`
- Full audit: profile analysis → rankings for primary/secondary keyword → Local Pack for main category → Q&A review → recommendations
- `Compare the Google Business Profile for "[my business]" with "[competitor 1]" and "[competitor 2]" in "[City,State,Country]"`

## Instagram / Cross-platform (sub-agent workflows)

- `Generate a comprehensive Instagram indexing report for @[handle]: analyze my website's entity structure, audit Instagram content indexing using search operators, and provide content alignment recommendations`
- `Analyze content alignment between my website and Instagram account @[handle]; identify entities well-covered on Instagram but missing from my website`

## Usage tips

1. Be specific: exact URLs, quoted keywords, explicit markets and date ranges.
2. One task per call; chain calls for composite work.
3. Verify outputs against the KG (GraphQL) or live sources before publishing.
4. Iterate: refine the message if the sub-agent picked the wrong tool.
