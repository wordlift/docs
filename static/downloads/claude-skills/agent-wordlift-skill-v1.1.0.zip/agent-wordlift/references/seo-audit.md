# SEO Audit with Competitive Schema Analysis

Merged from the standalone WordLift SEO Audit Skill (v1.0.0). This is the
*packaged workflow* layer: one invocation, a structured multi-part result,
and a branded report. Read this file when the user asks for an SEO audit of
a URL, a schema comparison against competitors, or a SERP gap analysis.

## Invocation

Call `wordlift_agent` with the audit task. Gather parameters first:

| Parameter | Required | Default | Notes |
|---|---|---|---|
| `target_url` | yes | — | The page to audit |
| `market` | no | `it-IT` | Locale, e.g. `en-US`, `fr-FR` — ask if ambiguous |
| `device` | no | `desktop` | `desktop` or `mobile` |
| `top_k_competitors` | no | 5 | SERP competitors to analyze |
| `query_hints` | no | — | Array of queries to guide intent inference |

Message shape for `wordlift_agent`:

```
Task: "seo_audit_competitors"
Parameters:
{
  "target_url": "<url>",
  "market": "<market>",
  "device": "<device>",
  "top_k_competitors": <n>,
  "query_hints": ["hint1", "hint2"],
  "trial": false
}
```

## Result processing

The agent returns four parts — use all of them, never dump raw JSON:

- `report_md` — markdown findings (source material, not the final report)
- `issues` — JSON array of schema gaps and recommendations
- `serp` — queries + competitor URLs
- `schema_diff` — coverage matrix: your structured data vs. competitors

Optionally verify or enrich with the KG: `entity(url:)` via
`wordlift_graphql_query` shows what the target page's entity actually
carries (see `graphql.md`), which grounds the "missing markup" claims.

## Report structure (required)

Produce a branded report with these seven sections, in order:

1. **Header** — `# 🎯 SEO Audit Report: [domain]`, *Powered by WordLift*,
   prominent **Overall SEO Score: XX/100**, Quick Stats table
   (schema types / critical issues / opportunities / passing), 2-3 sentence
   verdict.
2. **Score breakdown** — six dimensions with progress bars:
   🏷️ Schema Markup, 📝 Meta Tags, ✍️ Content Quality, ⚙️ Technical SEO,
   📱 Mobile Ready, ⚡ Performance. Color by score: 80-100 Leaf `#22A286`,
   60-79 Sand `#C2A41D`, 0-59 Berry `#D55471`.
3. **Issues & recommendations** — prioritized by severity (Critical 🔴
   Berry, Warning ⚠️ Sand, Info ℹ️ Sky `#3452DB`, Success ✅ Leaf). Each
   issue: title, Impact HIGH/MEDIUM/LOW, Category, business-impact
   description, numbered **Action Required** steps ending with how to test.
4. **Structured data inventory** — table of schema types:
   Status (✅ Found / ❌ **Missing**), Count, Priority.
5. **Competitive analysis** — ranked table (competitor, schema score,
   schema types used) with the target site placed in the ranking, plus one
   **Key Insight** callout.
6. **Growth opportunities** — ranked by Impact vs. Effort with estimated
   CTR/ROI where supportable; implementation steps + validation method.
   Never invent percentage claims — derive from `issues`/`schema_diff` or
   qualify as estimates.
7. **Footer** — WordLift attribution + generation date.

For detailed section examples and the React report-component reference,
load `seo-audit-report-format.md`. For the full design system (palette,
typography, badges, cards), load `branding.md`. Core palette for quick use:
Sky `#3452DB` (primary), Leaf `#22A286` (success), Sand `#C2A41D`
(warning), Berry `#D55471` (critical), Petal `#A10269` / Moss `#125054`
(accents), Neutral 900 `#191919` (text). Typography: Open Sans
(700 headers / 600 emphasis / 400 body).

## Troubleshooting

- **WordLift tools not found** → the MCP server isn't configured; point the
  user to https://docs.wordlift.io/agent-wordlift/integrations/ (MCP
  section: `https://mcp.wordlift.io/sse`).
- **Auth errors** → the API key needs configuring in the MCP settings, or
  the wrong key is active (`switch_credentials`).
- **Sparse audit result** → retry with `query_hints` reflecting the page's
  actual target queries; confirm the market matches the site's language.
