# WordLift GraphQL — Verified Reference

Every pattern marked ✅ was executed live against a production WordLift KG
via the MCP (`wordlift_graphql_query`). Patterns marked ⚠️ are
tenant-dependent — verify with introspection before relying on them.

## Contents

1. [Mental model](#1-mental-model)
2. [Introspection-first workflow](#2-introspection-first-workflow)
3. [Root fields](#3-root-fields)
4. [Property accessors](#4-property-accessors)
5. [Constraints and filtering](#5-constraints-and-filtering)
6. [Vector search (entitySearch)](#6-vector-search-entitysearch)
7. [Aggregations and topN](#7-aggregations-and-topn)
8. [Sorting and pagination](#8-sorting-and-pagination)
9. [Gotchas and corrections to older docs](#9-gotchas-and-corrections-to-older-docs)
10. [Recipe queries](#10-recipe-queries)

---

## 1. Mental model

The endpoint sits on top of an RDF graph. There is **no fixed output
schema**: you pull arbitrary RDF properties through typed accessor fields
(`string`, `ref`, `resource`, …) that take the property IRI/CURIE as a
`name` argument. Two querying styles coexist:

- **Schemaless**: `resource(iri: "…")` — direct node lookup, then walk
  properties.
- **Query DSL**: typed root fields (`entities`, `products`, `articles`, …)
  with per-type filter objects (`EntityQuery`, `ProductQuery`, …),
  pagination, and constraints.

The graph, the root fields, and the constraint sets **differ per tenant**.
The only universal contract is: `resource(iri:)`, `entities`, the accessor
fields, the `Constraint` input, and introspection.

## 2. Introspection-first workflow

✅ Introspection is enabled. This is your primary robustness tool — use it
instead of guessing.

```graphql
# What root fields does THIS graph expose?
{ __schema { queryType { fields { name args { name type { name } } } } } }

# What can I filter products by on THIS tenant?
{ __type(name: "ProductQuery") { inputFields { name } } }

# What filters does entitySearch accept here?
{ __type(name: "EntitySearch") { inputFields { name } } }

# Structure of a helper input
{ __type(name: "Constraint") { inputFields { name type { name kind } } } }
```

Verified finding: `ProductQuery` and `EntitySearch` had **different**
constraint sets on the same tenant (e.g. `priceConstraint` existed on
`EntitySearch` but not on `ProductQuery`). Never transfer a constraint from
one root field to another without checking.

## 3. Root fields

✅ Verified pattern: for ~25 schema.org types there is a **singular field
by IRI** and a **plural field with query/page/rows**:

`article/articles`, `product/products`, `faqPage/faqPages`,
`webpage/webpages`, `event/events`, `person/persons` (also `people`),
`organization/organizations`, `localBusiness/localBusinesses`,
`newsArticle/newsArticles`, `recipe/recipes`, `creativeWork/creativeWorks`,
`itemList/itemLists`, `podcastEpisode/podcastEpisodes`,
`productGroup/productGroups`, `seoKeyword/seoKeywords`,
`seovocQuery/seovocQueries`, `restaurant/restaurants`, plus tenant-specific
extras (verified sightings: `skiResorts`, `touristTrips`, `hospitals`,
`smartContents`, `posts`, `expEntities*`). **The exact list is per-tenant —
introspect.**

Universal fields:

```graphql
# Generic listing — works on every graph
{ entities(page: 0, rows: 25, query: { typeConstraint: {
    in: ["http://schema.org/Product"] } }) {
  id: iri
  types: refs(name: "rdf:type")
  name: string(name: "schema:name")
} }

# Schemaless node lookup ✅
{ resource(iri: "https://data.example.com/dataset/brands/acme") {
  iri
  name: string(name: "schema:name")
  types: refs(name: "rdf:type")
} }

# URL → entity lookup ✅ (exact match, trailing slash matters; returns a LIST)
{ entity(url: "https://www.example.com/knowledge-center/about-us/") {
  iri
  name: string(name: "schema:name")
  types: refs(name: "rdf:type")
} }
```

If `entity(url:)` returns `[]`, retry with/without trailing slash, or find
the canonical URL first via `webpages { url: string(name: "schema:url") }`.

## 4. Property accessors

✅ Full verified accessor surface on every entity node:

| Accessor | Returns | Notes |
|---|---|---|
| `iri` | Ref (non-null) | The node's identifier |
| `string(name:)` / `strings(name:)` | String / [String] | On a reference property, returns the **IRI as a string** |
| `int`, `ints`, `float`, `floats`, `bool`, `bools` | typed scalars | `float()` coerces numeric strings (e.g. price `"76000.0"` → `76000.0`) |
| `ref(name:)` / `refs(name:)` | IRI(s) | Use for `rdf:type` and any object property |
| `date`, `dates`, `dateTime`, `dateTimes`, `time`, `times` | temporal scalars | |
| `resource(name:)` / `resources(name:)` | nested Entity node(s) | Traversal; nest arbitrarily deep |
| `text(name:, lang:, langs:)` / `texts(...)` | LangText | Language-tagged literals (multilingual graphs) |
| `topN(name:, limit:, sort:)` | [Entity] | See §7 — `sort` is **required** |
| `aggregateInt` / `aggregateFloat(name:, operation:, aggregationField:)` | scalar | See §7 |

`name` accepts CURIEs (`schema:name`, `rdf:type`, `rdfs:label`) **and**
full IRIs (verified with `https://w3id.org/seovoc/...`). Alias every field
(`headline: string(name: "schema:headline")`) for readable JSON.

Nested traversal ✅:

```graphql
{ faqPages(page: 0, rows: 10) {
  id: iri
  questions: resources(name: "schema:mainEntity") {
    question: string(name: "schema:name")
    answer: resources(name: "schema:acceptedAnswer") {
      text: string(name: "schema:text")
    }
  }
} }
```

## 5. Constraints and filtering

✅ The `Constraint` input (verified via introspection):

```
contains: String        # substring/IRI match — FULL IRIs for types
in: [String]            # exact match, any of
notIn: [String]
regex: { pattern: String, i: Boolean, m: Boolean }
between: { lower: String, upper: String }
gt / gte / lt / lte: String   # note: String scalars, even for numbers/dates
exists: { exists: Boolean, excludeEmpty: Boolean }
```

Verified examples:

```graphql
# Type filter — FULL IRI required (CURIE fails silently) ✅
{ entities(page: 0, rows: 50, query: {
    typeConstraint: { in: ["http://schema.org/Product",
                           "http://schema.org/WebPage"] } }) { iri } }

# Case-insensitive regex — prefer the i flag over inline (?i) ✅
{ entities(rows: 25, query: {
    nameConstraint: { regex: { pattern: "gillig", i: true } } }) {
  iri name: string(name: "schema:name") } }

# Property-exists filter ✅
{ articles(rows: 25, query: {
    authorConstraint: { exists: { exists: true } } }) {
  headline: string(name: "schema:headline") } }

# Date range (constraint values are strings)
{ products(rows: 10, query: {
    createdConstraint: { between: { lower: "2023-01-01",
                                    upper: "2023-12-31" } } }) { iri } }
```

Constraint field naming: `<property>Constraint` (`nameConstraint`,
`urlConstraint`, `headlineConstraint`, `typeConstraint`, `iriConstraint`,
`gtinConstraint`, `skuConstraint`, …). Which ones exist depends on the root
field **and** tenant — introspect the `*Query` input type.

## 6. Vector search (entitySearch)

⚠️ Availability of the `search` block depends on vector search being
configured for the tenant. Verified working on a configured tenant;
verified **not configured** on others (returns errors/empty). Test with a
small query first; fall back to `wordlift_neural_search` (same capability,
simpler interface, returns URL + description + score) or to constraints.

```graphql
# Semantic search ✅
{ entitySearch(query: { search: { string: "school bus for church transport" } }) {
  iri
  name: string(name: "schema:name")
  score: float(name: "_:score")
} }

# Semantic search + type filter ✅ — the field is typeConstraint, NOT typeC
{ entitySearch(query: {
    search: { string: "luxury coach" }
    typeConstraint: { contains: "http://schema.org/Product" } }) {
  iri name: string(name: "schema:name") score: float(name: "_:score")
} }

# entitySearch also works constraint-only (no vector block) ✅
{ entitySearch(query: {
    nameConstraint: { regex: { pattern: "gillig", i: true } } }, rows: 10) {
  iri name: string(name: "schema:name") } }
```

`VectorSearch` input fields (introspected): `string`, `model`, `vector`,
`chunkset`. Plain `string` is sufficient in normal use.

`EntitySearch` is the constraint-richest input on most tenants (verified:
~50 constraints including `typeConstraint`, `nameConstraint`,
`descriptionConstraint`, `urlConstraint`, `priceConstraint`,
`keywordsConstraint`, geo and domain-specific ones). Introspect it to see
what your tenant supports.

## 7. Aggregations and topN

✅ Verified. Both operate **per entity node**, over the values of one of
its properties:

```graphql
# Average price across a product's offers ✅
{ products(page: 0, rows: 25) {
  name: string(name: "schema:name")
  avgPrice: aggregateFloat(name: "schema:offers",
                           operation: AVG,
                           aggregationField: "schema:price")
} }
```

`operation` is an enum: `SUM` | `AVG` (unquoted). All three args required.

```graphql
# Top-N related resources, sorted ✅ — sort is REQUIRED, direction is an
# unquoted enum (ASC | DESC); quoting it is a validation error
{ faqPages(page: 0, rows: 5) {
  top: topN(name: "schema:mainEntity", limit: 3,
            sort: { field: "schema:name", direction: ASC }) {
    q: string(name: "schema:name")
  }
} }
```

There is **no verified graph-wide count field**. To count, page through
with a minimal selection (`{ iri }`) and count client-side, or bound the
answer ("more than N").

## 8. Sorting and pagination

- Pagination ✅: `page` (0-based) + `rows` on all plural root fields.
  Iterate until an empty page. Keep `rows` ≤ 100.
- ⚠️ Top-level `orderBy` exists **only on `entitySearch`** (on the verified
  tenant) and takes an `EntitySort` **enum** — introspect its values; they
  are property-specific (verified values were only `startDate_ASC/DESC`,
  `endDate_ASC/DESC`, i.e. event-oriented). The older docs' example of
  `orderBy: [start_DESC, name_en_ASC]` on `events` did not validate on the
  tested tenant. If you need sorted output and the enum doesn't cover your
  field, sort client-side.

## 9. Gotchas and corrections to older docs

All verified live:

1. **`typeC` does not exist** — older spec examples use `typeC: { contains:
   "schema:Event" }` inside `entitySearch`; the actual field is
   `typeConstraint`. Using `typeC` is a validation error.
2. **CURIEs fail silently in constraints.** `typeConstraint: { contains:
   "schema:Product" }` returns `[]` with no error; the full IRI
   `http://schema.org/Product` works. Also mind `http` vs `https` — data
   was typed with `http://schema.org/` on the verified tenant.
3. **`string()` on an object property returns the IRI**, not the referenced
   node's label. To get the label, traverse: `resource(name:
   "schema:brand") { name: string(name: "schema:name") }`.
4. **`resource()` can return null even when the property exists** — when the
   referenced node has no resolvable local data. Diagnostic: query the same
   property with `ref()`/`refs()`; if an IRI comes back, the link exists but
   the target is thin. Report both, don't conclude "no author".
5. **Numeric literals may be stored as strings** (`"76000.0"`). Use
   `float(name:)` to coerce, or handle both in post-processing.
6. **`schema:name` may be null** on pages/articles — try
   `schema:headline`, `rdfs:label`, or `schema:url` as fallbacks before
   concluding data is missing.
7. **Comparison constraint values are Strings** (`gt: "100"`, `between: {
   lower: "2023-01-01", … }`), never bare numbers.
8. **Enum values are unquoted** (`direction: ASC`, `operation: AVG`).
   Quoting them is a validation error.
9. **Tenant ontologies are common** — expect custom namespaces in
   `rdf:type` and properties (`eyewear:`, `seovoc:`, …). Full IRIs always
   work in accessors when the prefix isn't registered.
10. **Validation errors are verbose and useful** — they name the offending
    field and the expected input type. Read them, introspect that type,
    retry. Empty results with no error usually mean a silent mismatch
    (wrong IRI form, wrong tenant/key, or genuinely no data).
11. **Wrong-looking data = wrong key.** All queries are scoped to the
    active API key. If the dataset URIs don't match the expected site, call
    `switch_credentials` with the correct key before proceeding.

## 10. Recipe queries

**KG identity probe** (always run first on an unfamiliar graph):
```graphql
{ entities(page: 0, rows: 3) {
  iri types: refs(name: "rdf:type") name: string(name: "schema:name") } }
```

**Content inventory by type** (page through):
```graphql
{ entities(page: 0, rows: 100, query: { typeConstraint: {
    in: ["http://schema.org/Article"] } }) {
  iri
  headline: string(name: "schema:headline")
  url: string(name: "schema:url")
  datePublished: string(name: "schema:datePublished")
} }
```

**Product catalog with brand and price**:
```graphql
{ products(page: 0, rows: 100) {
  id: iri
  name: string(name: "schema:name")
  brand: resource(name: "schema:brand") { name: string(name: "schema:name") }
  offers: resource(name: "schema:offers") {
    price: float(name: "schema:price")
    currency: string(name: "schema:priceCurrency")
  }
  image: string(name: "schema:image")
} }
```

**All Q&A pairs (FAQ export)**: see §4 nested traversal.

**Articles by author** (author stored as entity ref — match on IRI):
```graphql
{ articles(rows: 25, query: {
    authorConstraint: { regex: { pattern: "author/andrea", i: true } } }) {
  id: iri
  headline: string(name: "schema:headline")
  author: ref(name: "schema:author")
} }
```

**Markup coverage audit** ✅ (pages lacking a property — verified with
`exists: false` correctly returning only pages with null description):
```graphql
{ webpages(page: 0, rows: 100, query: {
    descriptionConstraint: { exists: { exists: false } } }) {
  iri url: string(name: "schema:url") } }
```
(Confirm the constraint exists on the tenant's `WebPageQuery` first;
otherwise pull all pages and filter client-side on null.)
