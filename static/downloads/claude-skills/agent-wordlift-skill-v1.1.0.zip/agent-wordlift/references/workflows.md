# Agent WordLift Workflows (MCP host-agent recipes)

End-to-end recipes combining `wordlift_agent`, `wordlift_graphql_query`, and
`wordlift_neural_search`. Adapted from docs.wordlift.io/agent-wordlift/workflows
for operation *from* a host agent (Claude/ChatGPT/Copilot) rather than the
WordLift web UI. Each step names the tool to call.

## 1. Keyword research

1. `wordlift_agent`: `generate keyword suggestions based on '[seed keyword]'`
2. `wordlift_agent`: `analyze the query '[best candidates]' on [market]` —
   intent + SERP landscape per candidate (one call each).
3. `wordlift_neural_search`: check what the site already has for each
   candidate topic → identify genuine gaps vs. optimization targets.
4. Synthesize: table of keyword / intent / existing coverage (URL) /
   action (create | optimize | consolidate).

## 2. Keyword cannibalization

1. GSC via `wordlift_agent`: `show me all queries where more than one page
   ranks over the last 90 days` (or per suspect query: pages + positions).
2. `wordlift_neural_search` with the query text → semantically overlapping
   pages beyond what GSC surfaces.
3. `wordlift_graphql_query`: pull `schema:about` / entity annotations for
   the competing URLs (via `entity(url:)`) to see if they target the same
   entities.
4. Recommend: canonical target, consolidation/redirect plan, internal-link
   re-pointing, differentiation of intent.

## 3. Rankings drop audit

1. `wordlift_agent` (GSC): compare clicks/impressions/position for the
   affected pages, before vs. after the drop window.
2. `wordlift_agent`: `analyze the query '[main query]' on [market]` — did
   the SERP change (new AI Overview, new competitors, layout shift)?
3. `wordlift_agent`: `Check if Google is showing an AI Overview for
   "[query]"` and which sites are cited.
4. `wordlift_agent`: `perform an entity gap analysis for '[URL]' against
   the query '[query]'`.
5. `wordlift_graphql_query`: verify the page's markup entity coverage in
   the KG (`entity(url:)` → types, about, mentions).
6. Deliver: cause hypothesis (SERP shift vs. content vs. technical) +
   prioritized fixes.

## 4. AI visibility analysis

1. Define the query set (brand + category + "best …" queries).
2. Per query, `wordlift_agent`: AI Overview presence + cited sources; then
   AI Mode result. One call per query per surface.
3. GA4 via `wordlift_agent`: AI referral traffic trend for context.
4. Score: cited / mentioned / absent per query; map absent queries to KG
   content gaps (neural search), recommend entity/content actions.

## 5. Content quality evaluation & query alignment

1. `wordlift_agent`: `evaluate the content quality for the keyword
   '[keyword]' in relation to the content on '[URL]'`.
2. `wordlift_agent`: entity gap analysis for the same URL/query.
3. Rewrite recommendations grounded in both outputs; verify claimed
   entities actually exist in the KG via GraphQL before promising markup.

## 6. Internal linking

1. `wordlift_neural_search`: top related content for the source page topic.
2. `wordlift_graphql_query`: fetch canonical URLs + titles for the
   candidate IRIs.
3. `wordlift_agent`: keyword suggestions per candidate → anchor selection
   (≤30 chars), never the homepage.
4. Output HTML link block; place links contextually, not in a list at the
   bottom.

## 7. FAQ generation

1. `wordlift_neural_search` + GSC (via `wordlift_agent`): real user
   questions around the topic.
2. Draft Q&A pairs grounded in site content (neural search results carry
   descriptions — use them).
3. Check existing coverage first: GraphQL `faqPages` nested query to avoid
   duplicating questions already marked up.

## 8. Product descriptions with keyword insights

1. GraphQL: pull the product node (name, brand, offers, attributes).
2. `wordlift_agent`: keyword suggestions for the product/category.
3. Write description + 4-6 highlights (1-150 chars each, no discounts),
   grounded only in KG attributes — never invent specs.

## 9. Authorship markup

1. GraphQL: `articles` with `authorConstraint: { exists: { exists: false } }`
   (introspect first) → pages missing authors; and `persons` → existing
   author entities to reuse.
2. Propose `schema:author` links to existing Person IRIs; only propose new
   Person entities when none exists.

## 10. Local SEO audit

All through `wordlift_agent`, sequentially: Business Profile analysis →
rankings for primary/secondary keywords → Local Pack for the main category
→ customer Q&A analysis → competitor profile comparison → consolidated
recommendations. See prompt-library.md for exact phrasings.

## 11. Instagram indexing analysis

1. `wordlift_agent`: full Instagram indexing report for @[handle] (entity
   structure + `site:instagram.com/[handle]` operator audit + alignment
   recommendations).
2. Cross-reference with KG entity inventory (GraphQL) to find entities
   covered on Instagram but missing on the website, and vice versa.

## General pattern

**Locate (neural search) → Extract (GraphQL) → Enrich (wordlift_agent live
data) → Synthesize (host agent).** Always verify KG-derived claims with the
actual query used, and state data windows for GSC/GA4 numbers.
