---
name: agent-wordlift
description: >-
  Operate Agent WordLift and query WordLift Knowledge Graphs through the
  WordLift MCP. Use this skill whenever the user mentions WordLift, Agent
  WordLift, AI visibility, GEO/AEO, entity gap analysis, AI Overview or AI Mode
  checks, semantic SEO, structured data audits, internal linking, keyword
  research via WordLift, Google Search Console or GA4 analysis through
  WordLift, or wants to query, inventory, audit, or export data from a
  WordLift Knowledge Graph (GraphQL, neural search, entities, products,
  articles, FAQs). Also use it for full SEO audits of a URL, comparing
  schema/structured-data coverage against SERP competitors, and generating
  branded WordLift audit reports. Also trigger when the user asks "what's
  in my knowledge graph", wants counts or lists of KG entities, or needs to
  switch between WordLift accounts/keys. Works with Claude, ChatGPT,
  Copilot, or any host agent connected to the WordLift MCP.
metadata:
  version: 1.1.0
  author: WordLift
  dependencies: WordLift MCP Server (https://mcp.wordlift.io/sse)
---

# Agent WordLift — SEO & Knowledge Graph Operations via MCP

This skill turns a host AI agent (Claude, ChatGPT, Copilot, Gemini) into an
effective operator of the WordLift MCP. WordLift exposes **four tools**; the
core of this skill is knowing which one to use and how to talk to each.

## The four tools

| Tool | What it is | Use it for |
|---|---|---|
| `wordlift_agent` | Natural-language gateway to WordLift's internal sub-agent (~20 SEO tools: SERP, AI Overview/AI Mode, GSC, GA4, Trends, keyword suggestions, entity gap, local SEO, Reddit, content evaluation, fact-checking) | Anything requiring live SEO data or multi-step SEO reasoning |
| `wordlift_graphql_query` | Raw GraphQL against the customer's Knowledge Graph | Deterministic KG reads: inventories, audits, counts, nested traversal, exports, URL→entity lookup |
| `wordlift_neural_search` | Vector search over the KG | Semantic retrieval when you don't know IRIs, types, or exact names |
| `switch_credentials` | Swap the active WordLift API key | Multi-account / agency work; each key = one KG |

## Routing rules

1. **Live SEO intelligence → `wordlift_agent`.** SERP analysis, AI Overview
   presence, AI Mode responses, GSC/GA4 queries, Google Trends, keyword
   suggestions, entity gap analysis, local SEO (Google Business Profile,
   Local Pack), Reddit insights, content quality evaluation, fact-checking.
   The sub-agent holds the API integrations; do not try to reproduce these
   with GraphQL.
2. **Full SEO audit of a URL (with competitor schema comparison) →
   packaged workflow.** When the user asks to "audit this URL", compare
   structured data with SERP competitors, or wants a branded audit report:
   read `references/seo-audit.md` and follow it — it invokes
   `wordlift_agent` with the `seo_audit_competitors` task and defines the
   required seven-section report format and WordLift branding
   (`references/branding.md`).
3. **Deterministic KG data → `wordlift_graphql_query`.** When the user wants
   facts *already in their graph* — list products, count FAQs, find the
   entity for a URL, extract all articles by an author, audit which pages
   lack markup. GraphQL is faster, cheaper, and exact; no LLM in the middle.
   **Read `references/graphql.md` before writing any query** — it contains
   the verified schema behavior, corrections to older docs, and the
   introspection-first workflow that makes queries robust across different
   KGs.
4. **Fuzzy KG retrieval → `wordlift_neural_search`.** "Find content about X
   on my site" when X isn't an exact name. Returns IRIs + URLs + scores +
   descriptions. Follow up with GraphQL on the returned IRIs for structured
   detail.
5. **Different site/account → `switch_credentials` first.** Everything is
   scoped to the active key. If results look like the wrong website, the
   wrong key is active — ask the user for the correct key.

Chain them: neural search to locate → GraphQL to extract → `wordlift_agent`
to enrich with live SERP/GSC data → synthesize in the host agent.

## Prompting `wordlift_agent`

It is an *agent*, not an API. Treat each `message` as a well-formed prompt:

- **One task per message.** Split composite requests into sequential calls.
- **Be explicit and self-contained**: include full URLs, exact keywords in
  quotes, the market/locale (e.g. `google.com`, `google.de`), date ranges
  for GSC/GA4, and the desired output shape. The sub-agent has no memory of
  your conversation.
- **Name the capability** when routing matters: "analyze the entities on…",
  "perform an entity gap analysis for…", "get the organic AI overview
  for…", "analyze my Google Search Console data…".
- Responses are text; parse and verify. For batch work (e.g. 20 keywords),
  iterate with one call per item rather than one giant prompt.

Proven prompt patterns per task family: `references/prompt-library.md`.
End-to-end multi-tool recipes (keyword research, cannibalization, rankings
drop audit, internal linking, local SEO audit, Instagram indexing):
`references/workflows.md`.

## Querying the Knowledge Graph (GraphQL)

Full guide with verified examples: `references/graphql.md`. The
non-negotiable habits:

1. **Introspect before assuming.** Every KG has a different schema — root
   fields, constraint sets, even custom types vary per tenant. Start with:
   ```graphql
   { __schema { queryType { fields { name } } } }
   ```
   and introspect the specific input type before filtering:
   ```graphql
   { __type(name: "ProductQuery") { inputFields { name } } }
   ```
2. **Use full IRIs in type constraints.** `typeConstraint: { in:
   ["http://schema.org/Product"] }`. CURIEs like `schema:Product` fail
   *silently* (empty results) in constraints. CURIEs are fine in property
   accessors: `string(name: "schema:name")`.
3. **Prefer `entities` + `typeConstraint`** as the universal listing
   pattern; typed root fields (`products`, `articles`, `faqPages`…) are
   convenient but their constraint sets differ per tenant.
4. **Page conservatively**: `rows: 25–100`, iterate `page` from 0. An empty
   page means you've reached the end.
5. **Expect nulls.** Properties are optional; `resource()` returns null when
   the referenced node has no local data (use `ref()` to still get the IRI).

## Multi-KG robustness checklist

Before any substantive KG work on an unfamiliar graph:

1. Probe identity: `{ entities(page: 0, rows: 3) { iri types: refs(name:
   "rdf:type") name: string(name: "schema:name") } }` — confirms the key,
   the dataset URI pattern, and data shape.
2. Introspect the root fields available on *this* graph.
3. Check whether vector search works (small `entitySearch` with a `search`
   block; if it errors or returns nothing, fall back to constraints or
   `wordlift_neural_search`).
4. Note custom namespaces in `rdf:type` values (tenant ontologies like
   `eyewear:`, `seovoc:` are common) and use their full IRIs when in doubt.

## Guardrails

- Never invent data: if a query returns empty, say so and show the query.
- GraphQL is read-only; writes go through WordLift APIs, not this MCP.
- Don't paste API keys into outputs; `switch_credentials` handles them.
- When reporting KG numbers (counts, coverage), state the query used so the
  result is reproducible.
